package com.example.easychat;

import com.google.firebase.messaging.FirebaseMessagingService;

public class FCMNotificationService extends FirebaseMessagingService {
}
